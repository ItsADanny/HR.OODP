 class ArtCollection
 {
     public readonly List<object> Collection = [];
     public void Add(object p) => Collection.Add(p);

     public void PrintCollection()
     {

     }
 }
