// Do not modify this file

 interface ICreator
 {
     public string CreatorName { get; }
 }
