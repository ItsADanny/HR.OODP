static class SentenceAnalyzer
{
    public static bool AreReversed(Sentence sentence1, Sentence sentence2)
    {
        return AreReversed(sentence1, sentence2, 0);
    }

    private static bool AreReversed(Sentence sentence1, Sentence sentence2, int index)
    {
        return false; // Replace with your logic
    }
}