static class SentenceUtils
{

}
