class Van
{
    public Van()
    {
       
    }

    public bool Load(Furniture furniture)
    {
       return false; // Replace with your logic
    }

    public List<Furniture> Unload()
    {
        return null; // Replace with your logic
    }

    public override string ToString()
    {
        return null; // Replace with your logic
    }
}
